<footer class="footer">
  <div class="container footer__inner">
    <div>
      <div class="footer__brand">EDKI Platform</div>
      <div class="muted">© <?= date('Y') ?>. Усі права захищено.</div>
    </div>
    <div class="footer__links">
      <a class="muted" href="/terms">Умови</a>
      <a class="muted" href="/privacy">Політика</a>
      <a class="muted" href="mailto:support@example.com">Підтримка</a>
    </div>
  </div>
</footer>
