<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
  // ✅ щоб cookie/сесія була однакова для всього сайту (часто лікує redirect-loop)
  session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'httponly' => true,
    'samesite' => 'Lax',
  ]);
  session_start();
}

/**
 * Простий .env loader (без бібліотек).
 * Читає файл web-php/.env або web-php/public/.env (якщо раптом там).
 */
(function () {
  $candidates = [
    dirname(__DIR__) . '/.env',          // web-php/.env
    dirname(__DIR__, 2) . '/.env',       // якщо структура інша
    dirname(__DIR__) . '/public/.env',   // web-php/public/.env (на всяк)
  ];

  $envFile = null;
  foreach ($candidates as $p) {
    if (is_file($p)) { $envFile = $p; break; }
  }
  if (!$envFile) return;

  $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
  if (!$lines) return;

  foreach ($lines as $line) {
    $line = trim($line);
    if ($line === '' || str_starts_with($line, '#')) continue;

    $pos = strpos($line, '=');
    if ($pos === false) continue;

    $key = trim(substr($line, 0, $pos));
    $val = trim(substr($line, $pos + 1));

    // прибираємо лапки якщо є
    if ((str_starts_with($val, '"') && str_ends_with($val, '"')) || (str_starts_with($val, "'") && str_ends_with($val, "'"))) {
      $val = substr($val, 1, -1);
    }

    // не перезаписуємо, якщо вже задано в середовищі
    if (getenv($key) === false) {
      putenv($key . '=' . $val);
      $_ENV[$key] = $val;
    }
  }
})();

require_once __DIR__ . '/db.php';
// users_store.php підключай у тих файлах, де потрібен (plan.php/email.php вже підключають)

function env(string $key, ?string $default = null): ?string {
  $v = getenv($key);
  if ($v === false || $v === '') return $default;
  return $v;
}

function redirect(string $path): void {
  header('Location: ' . $path, true, 302);
  exit;
}

function csrf_token(): string {
  if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
  }
  return (string)$_SESSION['csrf'];
}

function csrf_verify(?string $token): void {
  $ok = isset($_SESSION['csrf']) && is_string($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$token);
  if (!$ok) {
    http_response_code(419);
    echo "CSRF token invalid";
    exit;
  }
}

/**
 * ✅ FIX: user_id у тебе UUID/hex, тому тип має бути string.
 */
function auth_user_id(): ?string {
  $id = $_SESSION['user_id'] ?? null;
  if (!is_string($id) || $id === '') return null;
  return $id;
}

function auth_login(string $userId): void {
  $_SESSION['user_id'] = $userId;
  // has_access рахується у викликаючих файлах або через auth_refresh_access()
}

function auth_logout(): void {
  unset($_SESSION['user_id']);
  unset($_SESSION['has_access'], $_SESSION['plan']);
}

/**
 * ✅ Не обов’язково, але дуже корисно: перерахунок доступу по users.json.
 * Викликай на account-сторінках після require users_store.php.
 */
function auth_refresh_access(): void {
  if (!function_exists('user_find_by_id') || !function_exists('user_has_access')) {
    // якщо users_store ще не підключений
    return;
  }

  $uid = auth_user_id();
  if (!$uid) {
    $_SESSION['has_access'] = false;
    $_SESSION['plan'] = 'free';
    return;
  }

  $user = user_find_by_id($uid);
  if (!$user) {
    $_SESSION['has_access'] = false;
    $_SESSION['plan'] = 'free';
    return;
  }

  $_SESSION['plan'] = (string)($user['plan'] ?? 'free');
  $_SESSION['has_access'] = user_has_access($user);
}